import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  facts = [
    { title: "Premise", content: "Primal features a caveman at the dawn of evolution. A dinosaur on the brink of extinction. Bonded by tragedy, this unlikely friendship becomes the only hope of survival in a violent, primordial world."},
    { title: "Cast", content: "Aaron LaPlante as Spear[9], Ape-man #3, Big Gorilla, Screaming Caveman, Viking, Viking C, Constable, Soldier 1, Soldier 2, and Spear's Father.\n\nTom Kenny as Ape-man #1 and Ape-man #2.\n\nJon Olsen as Ape Shaman and Krog.\n\nAmanda Troop as Lula and Witches (Baba, Kira, Haga and Deena).\n\nLaetitia Eido-Mollon as Mira"}
  ]
}
